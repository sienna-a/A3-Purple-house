let circleX = 100;
let rectX = 450;
let squareSize;
let x, y, r, g, b;

function setup() {
	createCanvas(windowWidth, windowHeight);
	circleX = 100
	rectX = 450
}

function mousePressed () {
	circleX = 100
}

function draw() {
	//background
	b = map (mouseX, 0, 600, 0, 100);
	background (0, 0, b);
	
		noFill ();
	
	if (mouseX < 700){
		fill (255, 255, 255);
	}
	
	if (mouseX > 700){
		fill (255,255,0);
	}
	
		circle (circleX, 200, 150);
	
	fill('#D3B7F5');
	triangle (350, 400, 650, 100, 950, 400)
	
		fill('#D3B7F5');
	rect(350, 400, 600, 500)
	
		fill ('#834DC4');
	quad(650, 100, 1050, 100, 1350, 400, 950, 400);
	
		fill ('#834DC4');
	rect(950, 400, 400, 500)
	
	fill ('#89CFF0');
	strokeWeight(2);
stroke('#834DC4');
	circle (645, 250, 100)
	
	fill (r, g, b, 100);
		r = random (0, 250);
	g = 0
	b = random (0, 255);
	x = random (0, 600);
	y = random (0,600)
	stroke ('light blue');
	rect(450, 450, 50, 50)
	
	fill (r, g, b, 100);
		r = random (0, 250);
	g = 0
	b = random (0, 255);
	x = random (0, 600);
	y = random (0,600)
	stroke ('light blue');
	rect(620, 450, 50, 50)
	
		fill (r, g, b, 100);
		r = random (0, 250);
	g = 0
	b = random (0, 255);
	x = random (0, 600);
	y = random (0,600)
	stroke ('light blue');
	rect(790, 450, 50, 50)
	
	fill (r, g, b, 100);
		r = random (0, 250);
	g = 0
	b = random (0, 255);
	x = random (0, 600);
	y = random (0,600)
	stroke ('light blue');
	rect(450, 550, 50, 50)
	
fill (r, g, b, 100);
		r = random (0, 250);
	g = 0
	b = random (0, 255);
	x = random (0, 600);
	y = random (0,600)
	stroke ('light blue');
	rect(620, 550, 50, 50)
	
		fill (r, g, b, 100);
		r = random (0, 250);
	g = 0
	b = random (0, 255);
	x = random (0, 600);
	y = random (0,600)
	stroke ('light blue');
	rect(790, 650, 50, 50)
	
	fill (r, g, b, 100);
		r = random (0, 250);
	g = 0
	b = random (0, 255);
	x = random (0, 600);
	y = random (0,600)
	stroke ('light blue');
	rect(450, 650, 50, 50)
	
fill (r, g, b, 100);
		r = random (0, 250);
	g = 0
	b = random (0, 255);
	x = random (0, 600);
	y = random (0,600)
	stroke ('light blue');
	rect(620, 650, 50, 50)
	
		fill (r, g, b, 100);
		r = random (0, 250);
	g = 0
	b = random (0, 255);
	x = random (0, 600);
	y = random (0,600)
	stroke ('light blue');
	rect(790, 550, 50, 50)

	noFill ();
	
	if (mouseY < 700){
		fill ('#834DC4');
	}
	
	if (mouseY > 700){
		fill ('grey');
	}
	
		rect(rectX, 750, 400, 150);
	
	
	
	
	circleX = circleX + 1
	
}

